
# NN Suite: XOR + Hopfield (ODE) - PyQt6

Este proyecto extiende tu app PyQt6 original para incluir:
- **Entrenador XOR** (igual a tu base).
- **Pestaña Hopfield (memoria asociativa)** con:
  - Problema práctico: recuperación de imagen 10x10 (H/I) con ruido (corrección de ruido).
  - **Simulación ODE** \(\dot{x} = -x + W\tanh(\beta x)\) (está marcada en el código con "AQUÍ ESTÁ LA ECUACIÓN").
  - Comparación entre **Hebb** y **Pseudo-inversa**, y entre **β** distintos.
  - Gráficas de **Hamming** y **Energía aproximada**.
  - **Animación in-app** y opción para **exportar GIF/MP4** (MP4 requiere ffmpeg).

## Ejecución
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt
python app_pyqt6_hopfield.py
```

## Notas
- Para exportar MP4, instala ffmpeg en tu sistema (sino exporta GIF).
- El patrón objetivo se selecciona (H/I) y se puede ajustar ruido, β, dt y T.
